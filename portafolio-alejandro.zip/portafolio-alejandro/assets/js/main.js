/* =========================================================
   PORTAFOLIO ALEJANDRO — Lógica principal
   Vanilla JS, sin dependencias externas.
   1. Utilidades
   2. Navbar + menú móvil
   3. Scroll: progreso, header, botón volver arriba
   4. Animaciones de entrada (IntersectionObserver)
   5. Sección activa en el menú
   6. Texto rotativo (typing)
   7. Contadores animados
   8. Barras de habilidades
   9. Filtros de proyectos
   10. Formulario de contacto
   11. Pie de página
   ========================================================= */

(function () {
  "use strict";

  /* ---------- 1. UTILIDADES ---------- */
  const $ = (sel, ctx) => (ctx || document).querySelector(sel);
  const $$ = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /** Comprueba si el navegador soporta localStorage sin lanzar errores. */
  const safeStorage = {
    get(key) {
      try { return window.localStorage.getItem(key); } catch (e) { return null; }
    },
    set(key, value) {
      try { window.localStorage.setItem(key, value); } catch (e) { /* sin permisos */ }
    }
  };

  /* ---------- 2. NAVBAR + MENÚ MÓVIL ---------- */
  const nav = $("#nav");
  const navToggle = $("#navToggle");
  const navMenu = $("#navMenu");

  function setMenu(open) {
    navMenu.classList.toggle("is-open", open);
    navToggle.setAttribute("aria-expanded", String(open));
    navToggle.setAttribute("aria-label", open ? "Cerrar menú" : "Abrir menú");
    document.body.style.overflow = open ? "hidden" : "";
  }

  navToggle.addEventListener("click", () => {
    setMenu(navToggle.getAttribute("aria-expanded") !== "true");
  });

  // Cerrar el menú al pulsar cualquier enlace
  $$("#navMenu a").forEach((link) => link.addEventListener("click", () => setMenu(false)));

  // Cerrar al hacer clic fuera del menú
  document.addEventListener("click", (e) => {
    const isOpen = navMenu.classList.contains("is-open");
    if (isOpen && !navMenu.contains(e.target) && !navToggle.contains(e.target)) {
      setMenu(false);
    }
  });

  // Cerrar al volver a pantalla grande
  window.addEventListener("resize", () => {
    if (window.innerWidth > 880 && navMenu.classList.contains("is-open")) setMenu(false);
  });

  // Cerrar con la tecla Escape
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && navMenu.classList.contains("is-open")) {
      setMenu(false);
      navToggle.focus();
    }
  });

  /* ---------- 3. SCROLL ---------- */
  const progress = $("#scrollProgress");
  const toTop = $("#toTop");

  let ticking = false;

  function onScroll() {
    const y = window.scrollY;
    const height = document.documentElement.scrollHeight - window.innerHeight;

    // Barra de progreso
    const pct = height > 0 ? (y / height) * 100 : 0;
    progress.style.width = pct + "%";

    // Header compacto
    nav.classList.toggle("is-scrolled", y > 40);

    // Botón volver arriba
    toTop.classList.toggle("is-visible", y > 520);

    ticking = false;
  }

  window.addEventListener("scroll", () => {
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(onScroll);
    }
  }, { passive: true });

  onScroll();

  toTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
  });

  /* ---------- 4. ANIMACIONES DE ENTRADA ---------- */
  const revealItems = $$("[data-reveal]");

  // Aplicar el retardo definido en el HTML
  revealItems.forEach((el) => {
    const delay = el.dataset.revealDelay;
    if (delay) el.style.setProperty("--reveal-delay", delay + "ms");
  });

  if (reduceMotion || !("IntersectionObserver" in window)) {
    revealItems.forEach((el) => el.classList.add("is-visible"));
  } else {
    const revealObserver = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        obs.unobserve(entry.target);
      });
    }, { threshold: 0.14, rootMargin: "0px 0px -60px 0px" });

    revealItems.forEach((el) => revealObserver.observe(el));
  }

  // Animación inicial del título del hero
  requestAnimationFrame(() => {
    const hero = $(".hero");
    if (hero) hero.classList.add("is-loaded");
  });

  /* ---------- 5. SECCIÓN ACTIVA EN EL MENÚ ---------- */
  const sections = $$("main section[id]");
  const navLinks = $$('.nav__link[href^="#"]');

  function setActiveLink(id) {
    navLinks.forEach((link) => {
      link.classList.toggle("is-active", link.getAttribute("href") === "#" + id);
    });
  }

  if ("IntersectionObserver" in window) {
    const spy = new IntersectionObserver((entries) => {
      const visible = entries
        .filter((e) => e.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setActiveLink(visible.target.id);
    }, { threshold: 0.35, rootMargin: "-80px 0px -40% 0px" });

    sections.forEach((s) => spy.observe(s));
  }

  // Si el hero es la primera sección visible al cargar
  if (sections[0]) setActiveLink(sections[0].id);

  /* ---------- 6. TEXTO ROTATIVO ---------- */
  const typed = $("#typedRole");
  const phrases = [
    "interfaces responsivas",
    "diseño limpio y moderno",
    "sitios web veloces",
    "experiencias de usuario"
  ];

  if (typed) {
    if (reduceMotion) {
      typed.textContent = phrases[0];
    } else {
      let phraseIndex = 0;
      let charIndex = 0;
      let deleting = false;

      (function typeLoop() {
        const current = phrases[phraseIndex];

        typed.textContent = current.substring(0, charIndex);

        let delay = deleting ? 45 : 85;

        if (!deleting && charIndex === current.length) {
          delay = 1700;
          deleting = true;
        } else if (deleting && charIndex === 0) {
          deleting = false;
          phraseIndex = (phraseIndex + 1) % phrases.length;
          delay = 350;
        } else {
          charIndex += deleting ? -1 : 1;
        }

        setTimeout(typeLoop, delay);
      })();
    }
  }

  /* ---------- 7. CONTADORES ANIMADOS ---------- */
  function animateCount(el) {
    const target = parseInt(el.dataset.count, 10) || 0;
    const duration = 1500;
    const start = performance.now();

    if (reduceMotion) {
      el.textContent = target;
      return;
    }

    function step(now) {
      const p = Math.min((now - start) / duration, 1);
      // Salida suave (easeOutExpo)
      const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
      el.textContent = Math.round(target * eased);
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  /* ---------- 8. BARRAS DE HABILIDADES ---------- */
  function fillBar(bar) {
    bar.style.width = bar.dataset.progress + "%";
  }

  /* Un solo observer dispara contadores y barras al entrar en pantalla */
  const counters = $$("[data-count]");
  const bars = $$("[data-progress]");

  if (counters.length || bars.length) {
    if (reduceMotion || !("IntersectionObserver" in window)) {
      counters.forEach(animateCount);
      bars.forEach(fillBar);
    } else {
      const statsObserver = new IntersectionObserver((entries, obs) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          if (entry.target.dataset.count !== undefined) animateCount(entry.target);
          if (entry.target.dataset.progress !== undefined) fillBar(entry.target);
          obs.unobserve(entry.target);
        });
      }, { threshold: 0.5 });

      counters.forEach((el) => statsObserver.observe(el));
      bars.forEach((el) => statsObserver.observe(el));
    }
  }

  /* ---------- 9. FILTROS DE PROYECTOS ---------- */
  const filterButtons = $$(".filter");
  const cards = $$("#projectGrid .card");

  filterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterButtons.forEach((b) => b.classList.remove("is-active"));
      btn.classList.add("is-active");

      const filter = btn.dataset.filter;

      cards.forEach((card) => {
        const match = filter === "all" || card.dataset.category === filter;
        card.classList.toggle("is-hidden", !match);

        // Reiniciar la animación de entrada al cambiar de filtro
        if (match) {
          card.classList.remove("is-visible");
          void card.offsetWidth; // forzar reflow
          card.classList.add("is-visible");
        }
      });
    });
  });

  /* ---------- 10. FORMULARIO DE CONTACTO ---------- */
  const form = $("#contactForm");
  const submitBtn = $("#submitBtn");
  const toast = $("#toast");
  const toastText = $("#toastText");

  let toastTimer = null;

  function showToast(message) {
    toastText.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 3800);
  }

  const validators = {
    name(value) {
      if (!value.trim()) return "Por favor escribe tu nombre.";
      if (value.trim().length < 3) return "El nombre debe tener al menos 3 caracteres.";
      return "";
    },
    email(value) {
      if (!value.trim()) return "Por favor escribe tu email.";
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value.trim())) return "El email no parece válido.";
      return "";
    },
    subject(value) {
      if (!value) return "Selecciona un motivo de contacto.";
      return "";
    },
    message(value) {
      if (!value.trim()) return "Cuéntame un poco sobre tu proyecto.";
      if (value.trim().length < 10) return "El mensaje debe tener al menos 10 caracteres.";
      return "";
    }
  };

  function validateField(field) {
    const validator = validators[field.id];
    if (!validator) return true;

    const error = validator(field.value);
    const wrapper = field.closest(".field");
    const errorBox = $('[data-error-for="' + field.id + '"]', wrapper);

    if (error) {
      wrapper.classList.add("has-error");
      if (errorBox) errorBox.textContent = error;
      return false;
    }

    wrapper.classList.remove("has-error");
    if (errorBox) errorBox.textContent = "";
    return true;
  }

  if (form) {
    const fields = ["#name", "#email", "#subject", "#message"].map($).filter(Boolean);

    // Validar mientras el usuario escribe, solo si ya hubo error
    fields.forEach((field) => {
      field.addEventListener("input", () => {
        if (field.closest(".field").classList.contains("has-error")) validateField(field);
      });

      // Al salir del campo, validar siempre
      field.addEventListener("blur", () => {
        if (field.value) validateField(field);
      });
    });

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      const results = fields.map(validateField);
      const allValid = results.every(Boolean);

      if (!allValid) {
        const firstError = $(".field.has-error input, .field.has-error select, .field.has-error textarea", form);
        if (firstError) firstError.focus();
        showToast("Revisa los campos marcados en rojo.");
        return;
      }

      // Simula el envío (esta demo no manda correos reales)
      submitBtn.classList.add("is-loading");
      $(".btn__label", submitBtn).textContent = "Enviando...";

      setTimeout(() => {
        submitBtn.classList.remove("is-loading");
        $(".btn__label", submitBtn).textContent = "Enviar mensaje";
        form.reset();
        fields.forEach((f) => f.closest(".field").classList.remove("has-error"));
        showToast("¡Mensaje enviado! Te responderé muy pronto.");
        safeStorage.setItem("portafolio:lastMessage", String(Date.now()));
      }, 1400);
    });
  }

  /* ---------- 11. PIE DE PÁGINA ---------- */
  const year = $("#year");
  if (year) year.textContent = String(new Date().getFullYear());
})();
