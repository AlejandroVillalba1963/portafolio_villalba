# Portafolio — Alejandro · Desarrollador Web

Portafolio personal hecho con **HTML5, CSS3 y JavaScript vanilla** (sin frameworks ni dependencias).

## Estructura del proyecto

```
portafolio-alejandro/
├── index.html              → Estructura de la página
├── README.md               → Este archivo
└── assets/
    ├── css/
    │   └── style.css       → Todos los estilos y animaciones
    └── js/
        └── main.js         → Toda la lógica (vanilla JS)
```

## Cómo ver la página

**Opción 1 — la más simple**
Haz doble clic en `index.html`. Se abre en tu navegador y funciona todo.

**Opción 2 — desde Visual Studio Code**
1. Abre la carpeta: en VS Code ve a **Archivo → Abrir carpeta** y selecciona `portafolio-alejandro`.
2. Instala la extensión **Live Server** (por *Ritwick Dey*).
3. Abre `index.html` y presiona **Ctrl + Shift + P → "Live Server: Open with Live Server"**.

**Opción 3 — con Node.js (opcional)**
```bash
npx serve .
```

> Las rutas del proyecto son relativas, así que funciona igual abriendo el archivo directamente.

## Qué incluye

| Sección | Detalle |
|---|---|
| **Navbar** | Nombre "Alejandro", menú Inicio / Sobre mí / Proyectos / Contacto, botón "Contáctame", versión móvil con hamburguesa |
| **Hero** | "HOLA, SOY / ALEJANDRO / DESARROLLADOR WEB", texto rotativo con efecto máquina de escribir, descripción, botones **Ver proyectos** y **Contáctame**, y estadísticas animadas |
| **Avatar** | Círculo con gradiente morado, brillo pulsante, dos anillos que giran, órbita y etiquetas flotantes de tecnologías |
| **Sobre mí** | Biografía, datos personales, 5 barras de habilidades animadas y etiquetas de tecnologías |
| **Proyectos** | 6 tarjetas con filtro por categoría (Todos / Sitios web / Interfaces / Landing pages) |
| **Contacto** | Formulario con etiquetas flotantes, validación de campos, estado de carga y notificación de confirmación |
| **Extras** | Barra de progreso de lectura, botón "volver arriba", año automático, animaciones al hacer scroll, diseño responsive y soporte para `prefers-reduced-motion` |

## Detalles técnicos

- **Responsive**: punto de quiebre en `1024px`, `880px` (menú móvil), `620px` y `380px`.
- **Animaciones**: usan `IntersectionObserver` para activarse solo al entrar en pantalla, y `requestAnimationFrame` para los contadores.
- **Rendimiento**: el JS usa `requestAnimationFrame` con *throttling* en el scroll, y el observer deja de observar los elementos ya revelados.
- **Accesibilidad**: etiquetas `aria-*`, navegación por teclado, foco visible, `alt` en imágenes y respeto a `prefers-reduced-motion`.

## Cómo personalizarlo

**Cambiar textos, proyectos o datos de contacto**
Edita `index.html`. Todo el contenido visible está ahí, marcado con comentarios `<!-- ... -->`.

**Cambiar los colores**
Abre `assets/css/style.css` y edita las variables de la parte superior:
```css
--purple-600: #7c3aed;   /* morado principal */
--violet-400:  #a855f7;   /* violeta */
--navy-900:    #070b1c;   /* fondo azul marino */
--grad-main:   /* gradiente de los botones */
```

**Usar tu foto en el avatar**
En `index.html`, dentro de `.avatar__circle`, quita esta línea:
```html
<span class="avatar__initials" aria-hidden="true">A</span>
```
y déjala reemplazada por (crea primero la carpeta `assets/img/`):
```html
<img src="assets/img/avatar.jpg" alt="Foto de Alejandro" class="avatar__photo">
```

**Conectar el formulario a un correo real**
Ahora el formulario es una demo: valida los campos y muestra una confirmación, pero no envía nada. Para recibir mensajes de verdad, regístrate gratis en [Formspree](https://formspree.io) o [Web3Forms](https://web3forms.com), y en `index.html` cambia:
```html
<form class="form reveal" id="contactForm" novalidate>
```
por
```html
<form class="form reveal" id="contactForm" action="https://formspree.io/f/TU_ID" method="POST">
```
Luego ajusta el `preventDefault()` en `assets/js/main.js` para que solo se muestre la notificación cuando el envío sea exitoso.

**Quitar un proyecto**
Borra su `<article class="card">` completo dentro de `#projectGrid`. Si lo quitas, actualiza también `data-count="24"` en las estadísticas del hero.
